<?php
return array(
	'TMPL_FILE_DEPR'=>'_',
	'DEFAULT_THEME'=>'default',
);