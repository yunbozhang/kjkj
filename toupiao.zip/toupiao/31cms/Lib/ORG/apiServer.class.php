<?php
final class apiServer {
	public function __construct() {
		
	}
	public function getServerUrl(){
		return 'http://api.29w.com';
	}
}
?>