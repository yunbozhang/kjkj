<?php


	$contTpl = array(
	
		array(
			'tpltypeid'=>1,
			'tplview'=>'news1.png',
			'tpltypename'=>'yl_content',
			'tpldesinfo'=>'有头像',
		),	
		array(
			'tpltypeid'=>2,
			'tplview'=>'news2.png',
			'tpltypename'=>'ktv_content',
			'tpldesinfo'=>'无头像',
		),	
		array(
			'tpltypeid'=>3,
			'tplview'=>'news3.png',
			'tpltypename'=>'content_5xcg',
			'tpldesinfo'=>'无头像',
		),	
		array(
			'tpltypeid'=>4,
			'tplview'=>'news4.png',
			'tpltypename'=>'content_8xcv',
			'tpldesinfo'=>'无头像',
		),	
		array(
			'tpltypeid'=>5,
			'tplview'=>'news5.png',
			'tpltypename'=>'content_ghd6',
			'tpldesinfo'=>'无头像',
		),	
		array(
			'tpltypeid'=>6,
			'tplview'=>'news6.png',
			'tpltypename'=>'content_gkjs',
			'tpldesinfo'=>'无头像',
		),	
		array(
			'tpltypeid'=>7,
			'tplview'=>'news7.png',
			'tpltypename'=>'content_j5gd',
			'tpldesinfo'=>'无头像',
		),	
		array(
			'tpltypeid'=>8,
			'tplview'=>'news8.png',
			'tpltypename'=>'content_lidj',
			'tpldesinfo'=>'无头像',
		),	
		
		
		
	);
	
	
	return $contTpl;