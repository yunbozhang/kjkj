<?php

class DemoAction extends UserAction
{
public function index()
{
$this->display();
}
}
?>