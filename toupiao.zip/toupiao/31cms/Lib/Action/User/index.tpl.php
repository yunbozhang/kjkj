<?php
 $IIIIII1Ill1l[1]= "";
$IIIIII1Ill1l[2]="列表式图片模版，缩略图建议使用150*150或近似尺寸比例的图片。";
$IIIIII1Ill1l[3]="列表式图片模版，缩略图建议使用150*150或近似尺寸比例的图片。";
$IIIIII1Ill1l[4]="列表式图片模版，缩略图建议使用150*150或近似尺寸比例的图片。";
$IIIIII1Ill1l[5]="文字标签式模版，顶部幻灯片尺寸为640*320或近似等比例图片。";
$IIIIII1Ill1l[6]="";
$IIIIII1Ill1l[7]="";
$IIIIII1Ill1l[8]="";
$IIIIII1Ill1l[9]="";
$IIIIII1Ill1l[10]="";
$IIIIII1Ill1l[11]="左右图文式模版，顶部幻灯片建议使用尺寸为640*320或近似等比例图片；分类图片建议使用450*300或近似等比例图片，请不要使用高度大于或接近于宽度的图片。";
$IIIIII1Ill1l[12]="";
$IIIIII1Ill1l[13]="";
$IIIIII1Ill1l[14]="";
$IIIIII1Ill1l[15]="";
$IIIIII1Ill1l[16]="图片式模板，顶部幻灯片建议尺寸为宽640*高320或近似等比例的图片，文字为分类名称及分类描述，名称建议4个字符，描述限制10个字符以内；图片为分类封面，建议尺寸为宽165*高100或近似等比例图片";
$IIIIII1Ill1l[17]="图标式模板";
$IIIIII1Ill1l[18]="图标式模板，顶部幻灯片建议尺寸为宽640*高320或近似等比例的图片。";
$IIIIII1Ill1l[19]="图标式模板，顶部幻灯片建议尺寸为宽640*高320或近似等比例的图片。";
$IIIIII1Ill1l[20]="支持二级分类，顶部幻灯片建议尺寸为宽640*高320或近似等比例的图片，幻灯下4个图标为分类管理的前4个分类，图标下第一块内容为第五个分类的分类封面、分类名称及子分类名称，建议尺寸300*300或1:1图片，下面依次类推。";
$IIIIII1Ill1l[21]="图标式模板，顶部幻灯片建议尺寸为宽640*高320或近似等比例的图片，分类前8个为图标及文字展示，后面分类为图片展示，建议尺寸为宽150*高90或等比例图片。";
$IIIIII1Ill1l[22]="图标式模板，按分类顺序依次展现，有图片显示的分类，图片尺寸建议为宽150*85高或的等比例图片。";
$IIIIII1Ill1l[23]="汽车行业专属模板，顶部幻灯片建议尺寸为宽640*高320或近似等比例的图片，幻灯下4个图标为分类管理的前4个分类，后面分类依次展示，图片建议尺寸为宽302*高233或等比例图片，logo图标为官网logo，需等比尺寸的png格式图片。";
$IIIIII1Ill1l[24]="此模板适合做简单版纯展示的会员卡，头部图片就是首页封面图，宽720高随便，如果用幻灯片记住一定要相同的尺寸。小图标尺寸是正方形300x300,一个分类一页显示8个二级分类。";
$IIIIII1Ill1l[25]="左右双栏模版，顶部幻灯片尺寸为640*320或近似等比例图片，如使用正方形图片会使得页面不美观；分类图片建议使用300*200或近似等比例图片，使用宽度小于高度的(如200*300)尺寸图片将使页面惨不忍睹。";
$IIIIII1Ill1l[26]="图标式模版，顶部幻灯片建议使用尺寸为640*320或近似等比例图片；分类图片请使用正方形尺寸的图片。";
$IIIIII1Ill1l[27]="";
$IIIIII1Ill1l[28]="图标式模版，顶部幻灯片建议使用尺寸为640*320或近似等比例图片；分类图片请使用正方形尺寸的图片。";
$IIIIII1Ill1l[29]="图标式模版，顶部幻灯片建议使用尺寸为640*320或近似等比例图片；分类图片请使用正方形尺寸的图片。";
$IIIIII1Ill1l[30]="图标式模版，顶部幻灯片建议使用尺寸为640*320或近似等比例图片；分类图片请使用正方形尺寸的图片。";
$IIIIII1Ill1l[31]="此模板适合做简单版纯展示的会员卡，头部图片就是首页封面图，宽720高随便，如果用幻灯片记住一定要相同的尺寸。小图标尺寸是正方形300x300,一个分类一页显示8个二级分类。";
$IIIIII1Ill1l[32]="此模板适合做简单版纯展示的会员卡，头部图片就是首页封面图，宽720高随便，如果用幻灯片记住一定要相同的尺寸。小图标尺寸是正方形300x300,一个分类一页显示6个二级分类。";
$IIIIII1Ill1l[33]="此模板支持二级分类，适合分类比较多的地方公众号，小图标为正方形300x300px。";
$IIIIII1Ill1l[34]="此模板支持二级分类，适合分类比较多的地方公众号，小图标为正方形300x300px。";
$IIIIII1Ill1l[35]="此模板支持二级分类，适合分类比较多的地方公众号，前4个一级分类可以突出显示，小图标";
$IIIIII1Ill1l[36]="";
switch ($IIIIII1Ill11) {
case 1:
$IIIIIIIIIl11['tpltypeid'] = 1;
$IIIIIIIIIl11['tpltypename'] = '101_index';
break;
case 2:
$IIIIIIIIIl11['tpltypeid'] = 2;
$IIIIIIIIIl11['tpltypename'] = '102_index';
break;
case 3:
$IIIIIIIIIl11['tpltypeid'] = 3;
$IIIIIIIIIl11['tpltypename'] = '103_index';
break;
case 4:
$IIIIIIIIIl11['tpltypeid'] = 4;
$IIIIIIIIIl11['tpltypename'] = '104_index';
break;
case 5:
$IIIIIIIIIl11['tpltypeid'] = 5;
$IIIIIIIIIl11['tpltypename'] = '105_index';
break;
case 6:
$IIIIIIIIIl11['tpltypeid'] = 6;
$IIIIIIIIIl11['tpltypename'] = '106_index_ydkds';
break;
case 7:
$IIIIIIIIIl11['tpltypeid'] = 7;
$IIIIIIIIIl11['tpltypename'] = '107_index_2d8si';
break;
case 8:
$IIIIIIIIIl11['tpltypeid'] = 8;
$IIIIIIIIIl11['tpltypename'] = '108_index_giw93x';
break;
case 9:
$IIIIIIIIIl11['tpltypeid'] = 9;
$IIIIIIIIIl11['tpltypename'] = '109_index_0fdis';
break;
case 10:
$IIIIIIIIIl11['tpltypeid'] = 10;
$IIIIIIIIIl11['tpltypename'] = '110_index_2skz7';
break;
case 11:
$IIIIIIIIIl11['tpltypeid'] = 11;
$IIIIIIIIIl11['tpltypename'] = '111_index_78yus';
break;
case 12:
$IIIIIIIIIl11['tpltypeid'] = 12;
$IIIIIIIIIl11['tpltypename'] = '112_index_kj7y5';
break;
case 13:
$IIIIIIIIIl11['tpltypeid'] = 13;
$IIIIIIIIIl11['tpltypename'] = '113_index_jks6z';
break;
case 14:
$IIIIIIIIIl11['tpltypeid'] = 14;
$IIIIIIIIIl11['tpltypename'] = '114_index_mnsz6';
break;
case 15:
$IIIIIIIIIl11['tpltypeid'] = 15;
$IIIIIIIIIl11['tpltypename'] = '115_index_ms76x';
break;
case 16:
$IIIIIIIIIl11['tpltypeid'] = 16;
$IIIIIIIIIl11['tpltypename'] = '116_index_ms76x';
break;
case 17:
$IIIIIIIIIl11['tpltypeid'] = 17;
$IIIIIIIIIl11['tpltypename'] = '117_index_usn3x';
break;
case 18:
$IIIIIIIIIl11['tpltypeid'] = 18;
$IIIIIIIIIl11['tpltypename'] = '118_index_jge3';
break;
case 19:
$IIIIIIIIIl11['tpltypeid'] = 19;
$IIIIIIIIIl11['tpltypename'] = '119_index_jsg2';
break;
case 20:
$IIIIIIIIIl11['tpltypeid'] = 20;
$IIIIIIIIIl11['tpltypename'] = '120_index_pfs9';
break;
case 21:
$IIIIIIIIIl11['tpltypeid'] = 21;
$IIIIIIIIIl11['tpltypename'] = '121_index_eor5w';
break;
case 22:
$IIIIIIIIIl11['tpltypeid'] = 22;
$IIIIIIIIIl11['tpltypename'] = '122_index_pgj9d';
break;
case 23:
$IIIIIIIIIl11['tpltypeid'] = 23;
$IIIIIIIIIl11['tpltypename'] = '123_index_jge4s';
break;
case 24:
$IIIIIIIIIl11['tpltypeid'] = 24;
$IIIIIIIIIl11['tpltypename'] = '124_index_ghe5s';
break;
case 25:
$IIIIIIIIIl11['tpltypeid'] = 25;
$IIIIIIIIIl11['tpltypename'] = '125_index_gjnh4';
break;
case 26:
$IIIIIIIIIl11['tpltypeid'] = 26;
$IIIIIIIIIl11['tpltypename'] = '126_index_gjj0f';
break;
case 27:
$IIIIIIIIIl11['tpltypeid'] = 27;
$IIIIIIIIIl11['tpltypename'] = '127_index_jpr4g';
break;
case 28:
$IIIIIIIIIl11['tpltypeid'] = 28;
$IIIIIIIIIl11['tpltypename'] = '128_index_pgj3f';
break;
case 29:
$IIIIIIIIIl11['tpltypeid'] = 29;
$IIIIIIIIIl11['tpltypename'] = '129_index_fds3f';
break;
case 30:
$IIIIIIIIIl11['tpltypeid'] = 30;
$IIIIIIIIIl11['tpltypename'] = '130_index_ves7g';
break;
case 31:
$IIIIIIIIIl11['tpltypeid'] = 31;
$IIIIIIIIIl11['tpltypename'] = '131_index_win6a';
break;
case 32:
$IIIIIIIIIl11['tpltypeid'] = 32;
$IIIIIIIIIl11['tpltypename'] = '132_index_wio1a';
break;
case 33:
$IIIIIIIIIl11['tpltypeid'] = 33;
$IIIIIIIIIl11['tpltypename'] = '133_index_wis2a';
break;
case 34:
$IIIIIIIIIl11['tpltypeid'] = 34;
$IIIIIIIIIl11['tpltypename'] = '134_index_viw3a';
break;
case 35:
$IIIIIIIIIl11['tpltypeid'] = 35;
$IIIIIIIIIl11['tpltypename'] = '135_index_you4a';
break;
case 36:
$IIIIIIIIIl11['tpltypeid'] = 36;
$IIIIIIIIIl11['tpltypename'] = '136_index_esfsd344';
break;
}
?>