<?php

class ToolAction extends UserAction{
public function index(){
$this->display();
}
}
?>