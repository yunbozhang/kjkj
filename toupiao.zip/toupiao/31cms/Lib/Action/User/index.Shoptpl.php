<?php

$IIIIIIl1lI11 = array(
array(
'shoptpltypeid'=>1,
'shoptplview'=>'cate1.png',
'shoptpltypename'=>'101_index',
'shoptpldesinfo'=>'',
'attr'=>'thumb focu bgs',
'sort'=>1,
),
array(
'shoptpltypeid'=>2,
'shoptplview'=>'cate2.png',
'shoptpltypename'=>'102_index',
'shoptpldesinfo'=>'列表式图片模版，缩略图建议使用150*150或近似尺寸比例的图片。',
'attr'=>'focu bgs lis',
'sort'=>2,
),
array(
'shoptpltypeid'=>3,
'shoptplview'=>'cate3.png',
'shoptpltypename'=>'103_index',
'shoptpldesinfo'=>'列表式图片模版，缩略图建议使用150*150或近似尺寸比例的图片。',
'attr'=>'focu bgs lis',
'sort'=>3,
),
array(
'shoptpltypeid'=>4,
'shoptplview'=>'cate4.png',
'shoptpltypename'=>'104_index',
'shoptpldesinfo'=>'列表式图片模版，缩略图建议使用150*150或近似尺寸比例的图片。',
'attr'=>'thumb focu bgs lis',
'sort'=>4,
),
array(
'shoptpltypeid'=>5,
'shoptplview'=>'cate9.png',
'shoptpltypename'=>'105_index',
'shoptpldesinfo'=>'文字标签式模版，顶部幻灯片尺寸为640*320或近似等比例图片。',
'attr'=>'focu bgs',
'sort'=>5,
),
array(
'shoptpltypeid'=>6,
'shoptplview'=>'cate106.png',
'shoptpltypename'=>'106_index_ydkds',
'shoptpldesinfo'=>'',
'attr'=>'focu thumb bgs',
'sort'=>6,
),
array(
'shoptpltypeid'=>7,
'shoptplview'=>'cate107.png',
'shoptpltypename'=>'107_index_2d8si',
'shoptpldesinfo'=>'',
'attr'=>'focu thumb bgs',
'sort'=>7,
),
array(
'shoptpltypeid'=>8,
'shoptplview'=>'cate108.png',
'shoptpltypename'=>'108_index_giw93x',
'shoptpldesinfo'=>'',
'attr'=>'filt focu bgs',
'sort'=>8,
),
array(
'shoptpltypeid'=>9,
'shoptplview'=>'cate109.png',
'shoptpltypename'=>'109_index_0fdis',
'shoptpldesinfo'=>'',
'attr'=>'focu bgs',
'sort'=>9,
),
array(
'shoptpltypeid'=>10,
'shoptplview'=>'cate110.png',
'shoptpltypename'=>'110_index_2skz7',
'shoptpldesinfo'=>'',
'attr'=>'bgs focu thumb',
'sort'=>10,
),
array(
'shoptpltypeid'=>11,
'shoptplview'=>'cate111.png',
'shoptpltypename'=>'111_index_78yus',
'shoptpldesinfo'=>'左右图文式模版，顶部幻灯片建议使用尺寸为640*320或近似等比例图片；分类图片建议使用450*300或近似等比例图片，请不要使用高度大于或接近于宽度的图片。',
'attr'=>'bgs focu thumb',
'sort'=>11,
),
array(
'shoptpltypeid'=>12,
'shoptplview'=>'cate112.png',
'shoptpltypename'=>'112_index_kj7y5',
'shoptpldesinfo'=>'',
'attr'=>'bg bgs filt',
'sort'=>12,
),
array(
'shoptpltypeid'=>13,
'shoptplview'=>'cate113.png',
'shoptpltypename'=>'113_index_jks6z',
'shoptpldesinfo'=>'',
'attr'=>'bg bgs filt',
'sort'=>13,
),
array(
'shoptpltypeid'=>14,
'shoptplview'=>'cate114.png',
'shoptpltypename'=>'114_index_mnsz6',
'shoptpldesinfo'=>'',
'attr'=>'thumb filt bg bgs',
'sort'=>14,
),
array(
'shoptpltypeid'=>15,
'shoptplview'=>'cate115.png',
'shoptpltypename'=>'115_index_ms76x',
'shoptpldesinfo'=>'',
'attr'=>'bgs bg filt',
'sort'=>15,
),
array(
'shoptpltypeid'=>16,
'shoptplview'=>'cate116.png',
'shoptpltypename'=>'116_index_ms76x',
'shoptpldesinfo'=>'图片式模板，顶部幻灯片建议尺寸为宽640*高320或近似等比例的图片，文字为分类名称及分类描述，名称建议4个字符，描述限制10个字符以内；图片为分类封面，建议尺寸为宽165*高100或近似等比例图片',
'attr'=>'thumb focu bgs',
'sort'=>16,
),
array(
'shoptpltypeid'=>17,
'shoptplview'=>'cate117.png',
'shoptpltypename'=>'117_index_usn3x',
'shoptpldesinfo'=>'图标式模板',
'attr'=>'thumb filt bg bgs',
'sort'=>17,
),
array(
'shoptpltypeid'=>18,
'shoptplview'=>'cate118.png',
'shoptpltypename'=>'118_index_jge3',
'shoptpldesinfo'=>'图标式模板，顶部幻灯片建议尺寸为宽640*高320或近似等比例的图片。',
'attr'=>'thumb focu bgs',
'sort'=>18,
),
array(
'shoptpltypeid'=>19,
'shoptplview'=>'cate119.png',
'shoptpltypename'=>'119_index_jsg2',
'shoptpldesinfo'=>'图标式模板，顶部幻灯片建议尺寸为宽640*高320或近似等比例的图片。',
'attr'=>'focu thumb bgs',
'sort'=>19,
),
array(
'shoptpltypeid'=>20,
'shoptplview'=>'cate120.png',
'shoptpltypename'=>'120_index_pfs9',
'shoptpldesinfo'=>'支持二级分类，顶部幻灯片建议尺寸为宽640*高320或近似等比例的图片，幻灯下4个图标为分类管理的前4个分类，图标下第一块内容为第五个分类的分类封面、分类名称及子分类名称，建议尺寸300*300或1:1图片，下面依次类推。',
'attr'=>'focu thumb bgs',
'sort'=>20,
),
array(
'shoptpltypeid'=>21,
'shoptplview'=>'cate121.png',
'shoptpltypename'=>'121_index_eor5w',
'shoptpldesinfo'=>'图标式模板，顶部幻灯片建议尺寸为宽640*高320或近似等比例的图片，分类前8个为图标及文字展示，后面分类为图片展示，建议尺寸为宽150*高90或等比例图片。',
'attr'=>'focu bgs thumb',
'sort'=>21,
),
array(
'shoptpltypeid'=>22,
'shoptplview'=>'cate122.png',
'shoptpltypename'=>'122_index_pgj9d',
'shoptpldesinfo'=>'图标式模板，按分类顺序依次展现，有图片显示的分类，图片尺寸建议为宽150*85高或的等比例图片。',
'attr'=>'bgs thumb',
'sort'=>22,
),
array(
'shoptpltypeid'=>23,
'shoptplview'=>'cate123.png',
'shoptpltypename'=>'123_index_jge4s',
'shoptpldesinfo'=>'汽车行业专属模板，顶部幻灯片建议尺寸为宽640*高320或近似等比例的图片，幻灯下4个图标为分类管理的前4个分类，后面分类依次展示，图片建议尺寸为宽302*高233或等比例图片，logo图标为官网logo，需等比尺寸的png格式图片。',
'attr'=>'focu bgs',
'sort'=>23,
),
array(
'shoptpltypeid'=>24,
'shoptplview'=>'cate124.png',
'shoptpltypename'=>'124_index_ghe5s',
'shoptpldesinfo'=>'此模板适合做简单版纯展示的会员卡，头部图片就是首页封面图，宽720高随便，如果用幻灯片记住一定要相同的尺寸。小图标尺寸是正方形300x300,一个分类一页显示8个二级分类。',
'attr'=>'sub focu bgs thumb',
'sort'=>24,
),
array(
'shoptpltypeid'=>25,
'shoptplview'=>'cate125.png',
'shoptpltypename'=>'125_index_gjnh4',
'shoptpldesinfo'=>'左右双栏模版，顶部幻灯片尺寸为640*320或近似等比例图片，如使用正方形图片会使得页面不美观；分类图片建议使用300*200或近似等比例图片，使用宽度小于高度的(如200*300)尺寸图片将使页面惨不忍睹。',
'attr'=>'bgs focu thumb',
'sort'=>25,
),
array(
'shoptpltypeid'=>26,
'shoptplview'=>'cate126.png',
'shoptpltypename'=>'126_index_gjj0f',
'shoptpldesinfo'=>'图标式模版，顶部幻灯片建议使用尺寸为640*320或近似等比例图片；分类图片请使用正方形尺寸的图片。',
'attr'=>'focu thumb bgs',
'sort'=>26,
),
array(
'shoptpltypeid'=>27,
'shoptplview'=>'cate127.png',
'shoptpltypename'=>'127_index_jpr4g',
'shoptpldesinfo'=>'',
'attr'=>'focu bgs thumb',
'sort'=>27,
),
array(
'shoptpltypeid'=>28,
'shoptplview'=>'cate128.png',
'shoptpltypename'=>'128_index_pgj3f',
'shoptpldesinfo'=>'图标式模版，顶部幻灯片建议使用尺寸为640*320或近似等比例图片；分类图片请使用正方形尺寸的图片。',
'attr'=>'focu bgs thumb',
'sort'=>28,
),
array(
'shoptpltypeid'=>29,
'shoptplview'=>'cate129.png',
'shoptpltypename'=>'129_index_fds3f',
'shoptpldesinfo'=>'图标式模版，顶部幻灯片建议使用尺寸为640*320或近似等比例图片；分类图片请使用正方形尺寸的图片。',
'attr'=>'focu bgs thumb',
'sort'=>29,
),
array(
'shoptpltypeid'=>30,
'shoptplview'=>'cate130.png',
'shoptpltypename'=>'130_index_ves7g',
'shoptpldesinfo'=>'图标式模版，顶部幻灯片建议使用尺寸为640*320或近似等比例图片；分类图片请使用正方形尺寸的图片。',
'attr'=>'focu bgs thumb',
'sort'=>30,
),
array(
'shoptpltypeid'=>31,
'shoptplview'=>'cate131.png',
'shoptpltypename'=>'131_index_win6a',
'shoptpldesinfo'=>'此模板适合做简单版纯展示的会员卡，头部图片就是首页封面图，宽720高随便，如果用幻灯片记住一定要相同的尺寸。小图标尺寸是正方形300x300,一个分类一页显示8个二级分类。',
'attr'=>'sub focu bgs thumb',
'sort'=>31,
),
array(
'shoptpltypeid'=>32,
'shoptplview'=>'cate132.png',
'shoptpltypename'=>'132_index_wio1a',
'shoptpldesinfo'=>'此模板适合做简单版纯展示的会员卡，头部图片就是首页封面图，宽720高随便，如果用幻灯片记住一定要相同的尺寸。小图标尺寸是正方形300x300,一个分类一页显示6个二级分类。',
'attr'=>'sub focu bgs thumb',
'sort'=>32,
),
array(
'shoptpltypeid'=>33,
'shoptplview'=>'cate133.png',
'shoptpltypename'=>'133_index_wis2a',
'shoptpldesinfo'=>'此模板支持二级分类，适合分类比较多的地方公众号，小图标为正方形300x300px。',
'attr'=>'sub focu bgs thumb',
'sort'=>33,
),
array(
'shoptpltypeid'=>34,
'shoptplview'=>'cate134.png',
'shoptpltypename'=>'134_index_viw3a',
'shoptpldesinfo'=>'此模板支持二级分类，适合分类比较多的地方公众号，小图标为正方形300x300px。',
'attr'=>'sub focu bgs thumb',
'sort'=>34,
),
array(
'shoptpltypeid'=>35,
'shoptplview'=>'cate135.png',
'shoptpltypename'=>'135_index_you4a',
'shoptpldesinfo'=>'此模板支持二级分类，适合分类比较多的地方公众号，前4个一级分类可以突出显示，小图标',
'attr'=>'focu bgs thumb',
'sort'=>35,
),
array(
'shoptpltypeid'=>36,
'shoptplview'=>'cate136.png',
'shoptpltypename'=>'136_index_esfsd344',
'shoptpldesinfo'=>'',
'attr'=>'thumb bg bgs filt',
'sort'=>36,
),
array(
'shoptpltypeid'=>37,
'shoptplview'=>'list1.png',
'shoptpltypename'=>'yl_list',
'shoptpldesinfo'=>'',
'attr'=>'lis',
'sort'=>37,
),
array(
'shoptpltypeid'=>38,
'shoptplview'=>'list4.png',
'shoptpltypename'=>'ktv_list',
'shoptpldesinfo'=>'',
'attr'=>'lis',
'sort'=>38,
),
array(
'shoptpltypeid'=>39,
'shoptplview'=>'cate139.png',
'shoptpltypename'=>'139_index_ktv',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'focu thumb filt',
'sort'=>39,
),
array(
'shoptpltypeid'=>40,
'shoptplview'=>'cate140.png',
'shoptpltypename'=>'140_index_qesf',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'focu thumb bgs',
'sort'=>40,
),
array(
'shoptpltypeid'=>41,
'shoptplview'=>'cate141.png',
'shoptpltypename'=>'141_index_654d',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'focu thumb bgs',
'sort'=>41,
),
array(
'shoptpltypeid'=>42,
'shoptplview'=>'cate142.png',
'shoptpltypename'=>'142_index_6uid',
'shoptpldesinfo'=>'无头部幻灯片，小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs filt bg thumb',
'sort'=>42,
),
array(
'shoptpltypeid'=>43,
'shoptplview'=>'cate143.png',
'shoptpltypename'=>'143_index_53sd',
'shoptpldesinfo'=>'无头部幻灯片，小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs filt bg thumb',
'sort'=>43,
),
array(
'shoptpltypeid'=>44,
'shoptplview'=>'cate144.png',
'shoptpltypename'=>'144_index_bfst',
'shoptpldesinfo'=>'无头部幻灯片，小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs bg thumb',
'sort'=>44,
),
array(
'shoptpltypeid'=>45,
'shoptplview'=>'cate145.png',
'shoptpltypename'=>'145_index_vbws',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>45,
),
array(
'shoptpltypeid'=>46,
'shoptplview'=>'cate146.png',
'shoptpltypename'=>'146_index_58sv',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>46,
),
array(
'shoptpltypeid'=>47,
'shoptplview'=>'cate147.png',
'shoptpltypename'=>'147_index_verm',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>47,
),
array(
'shoptpltypeid'=>48,
'shoptplview'=>'cate148.png',
'shoptpltypename'=>'148_index_bleu',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>48,
),
array(
'shoptpltypeid'=>49,
'shoptplview'=>'cate149.png',
'shoptpltypename'=>'149_index_28ad',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>49,
),
array(
'shoptpltypeid'=>50,
'shoptplview'=>'cate150.png',
'shoptpltypename'=>'150_index_28sv',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>50,
),
array(
'shoptpltypeid'=>51,
'shoptplview'=>'cate151.png',
'shoptpltypename'=>'151_index_ve4y',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>51,
),
array(
'shoptpltypeid'=>52,
'shoptplview'=>'cate152.png',
'shoptpltypename'=>'152_index_v82x',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>52,
),
array(
'shoptpltypeid'=>53,
'shoptplview'=>'cate153.png',
'shoptpltypename'=>'153_index_58sdf',
'shoptpldesinfo'=>'诺基亚X风格，披着wp外衣的android，不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>53,
),
array(
'shoptpltypeid'=>54,
'shoptplview'=>'cate154.png',
'shoptpltypename'=>'154_index_f78d1',
'shoptpldesinfo'=>'诺基亚X风格2，不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>54,
),
array(
'shoptpltypeid'=>55,
'shoptplview'=>'cate155.png',
'shoptpltypename'=>'155_index_xym7',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>55,
),
array(
'shoptpltypeid'=>56,
'shoptplview'=>'cate156.png',
'shoptpltypename'=>'156_index_64ay',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>56,
),
array(
'shoptpltypeid'=>57,
'shoptplview'=>'cate157.png',
'shoptpltypename'=>'157_index_dgeh7',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>57,
),
array(
'shoptpltypeid'=>58,
'shoptplview'=>'cate158.png',
'shoptpltypename'=>'158_index_ffy4',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>58,
),
array(
'shoptpltypeid'=>59,
'shoptplview'=>'cate159.png',
'shoptpltypename'=>'159_index_fgft',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>59,
),
array(
'shoptpltypeid'=>60,
'shoptplview'=>'cate160.png',
'shoptpltypename'=>'160_index_674f',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>60,
),
array(
'shoptpltypeid'=>61,
'shoptplview'=>'cate161.png',
'shoptpltypename'=>'161_index_df3t',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>61,
),
array(
'shoptpltypeid'=>62,
'shoptplview'=>'cate162.png',
'shoptpltypename'=>'162_index_xffe',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>62,
),
array(
'shoptpltypeid'=>63,
'shoptplview'=>'cate163.png',
'shoptpltypename'=>'163_index_cve3',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>63,
),
array(
'shoptpltypeid'=>64,
'shoptplview'=>'cate164.png',
'shoptpltypename'=>'164_index_5366',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu filt lis',
'sort'=>64,
),
array(
'shoptpltypeid'=>65,
'shoptplview'=>'cate165.png',
'shoptpltypename'=>'165_index_6dgbf',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>65,
),
array(
'shoptpltypeid'=>66,
'shoptplview'=>'cate166.png',
'shoptpltypename'=>'166_index_6dgbf',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>66,
),
array(
'shoptpltypeid'=>67,
'shoptplview'=>'cate167.png',
'shoptpltypename'=>'167_index_6dgbf',
'shoptpldesinfo'=>'小图标为正方形300x300px，图片建议360x200px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>67,
),
array(
'shoptpltypeid'=>68,
'shoptplview'=>'cate168.png',
'shoptpltypename'=>'168_index_6dgbf',
'shoptpldesinfo'=>'小图标为正方形300x300px，图片建议360x200px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>68,
),
array(
'shoptpltypeid'=>69,
'shoptplview'=>'cate169.png',
'shoptpltypename'=>'169_index_6dgbf',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>69,
),
array(
'shoptpltypeid'=>70,
'shoptplview'=>'cate170.png',
'shoptpltypename'=>'170_index_6dgbf',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>70,
),
array(
'shoptpltypeid'=>71,
'shoptplview'=>'cate171.png',
'shoptpltypename'=>'171_index_stbn',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>71,
),
array(
'shoptpltypeid'=>72,
'shoptplview'=>'cate172.png',
'shoptpltypename'=>'172_index_44g3',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>72,
),
array(
'shoptpltypeid'=>73,
'shoptplview'=>'cate173.png',
'shoptpltypename'=>'173_index_6dff',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>73,
),
array(
'shoptpltypeid'=>74,
'shoptplview'=>'cate174.png',
'shoptpltypename'=>'174_index_gh46',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>74,
),
array(
'shoptpltypeid'=>75,
'shoptplview'=>'cate175.png',
'shoptpltypename'=>'175_index_6deh',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>75,
),
array(
'shoptpltypeid'=>76,
'shoptplview'=>'cate176.png',
'shoptpltypename'=>'176_index_sda3',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>76,
),
array(
'shoptpltypeid'=>77,
'shoptplview'=>'cate177.png',
'shoptpltypename'=>'177_index_gh5f',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>77,
),
array(
'shoptpltypeid'=>78,
'shoptplview'=>'cate178.png',
'shoptpltypename'=>'178_index_shfr',
'shoptpldesinfo'=>'不支持更换颜色风格',
'attr'=>'bgs focu lis',
'sort'=>78,
),
array(
'shoptpltypeid'=>79,
'shoptplview'=>'cate179.png',
'shoptpltypename'=>'179_index_4g4f',
'shoptpldesinfo'=>'不支持更换颜色风格',
'attr'=>'bgs focu lis',
'sort'=>79,
),
array(
'shoptpltypeid'=>80,
'shoptplview'=>'cate180.png',
'shoptpltypename'=>'180_index_zfg4',
'shoptpldesinfo'=>'不支持更换颜色风格',
'attr'=>'bgs focu lis',
'sort'=>80,
),
array(
'shoptpltypeid'=>81,
'shoptplview'=>'cate181.png',
'shoptpltypename'=>'181_index_dfg3',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>81,
),
array(
'shoptpltypeid'=>82,
'shoptplview'=>'cate182.png',
'shoptpltypename'=>'182_index_sd3v',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>82,
),
array(
'shoptpltypeid'=>83,
'shoptplview'=>'cate183.png',
'shoptpltypename'=>'183_index_zdfe',
'shoptpldesinfo'=>'图片高度100，宽度不小于360px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>83,
),
array(
'shoptpltypeid'=>84,
'shoptplview'=>'cate184.png',
'shoptpltypename'=>'184_index_sdf3',
'shoptpldesinfo'=>'图片高度100，宽度不小于360px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>84,
),
array(
'shoptpltypeid'=>85,
'shoptplview'=>'cate185.png',
'shoptpltypename'=>'185_index_gjerf',
'shoptpldesinfo'=>'图片高度75，宽度不小于360px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>85,
),
array(
'shoptpltypeid'=>86,
'shoptplview'=>'cate186.png',
'shoptpltypename'=>'186_index_aasd',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>86,
),
array(
'shoptpltypeid'=>87,
'shoptplview'=>'cate187.png',
'shoptpltypename'=>'187_index_4d8fw',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>87,
),
array(
'shoptpltypeid'=>88,
'shoptplview'=>'cate188.png',
'shoptpltypename'=>'188_index_gcbr5',
'shoptpldesinfo'=>'图标为正方形300x300px，图片建议360x200px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>88,
),
array(
'shoptpltypeid'=>89,
'shoptplview'=>'cate189.png',
'shoptpltypename'=>'189_index_xcv2',
'shoptpldesinfo'=>'图标为正方形300x300px，图片建议360x200px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>89,
),
array(
'shoptpltypeid'=>90,
'shoptplview'=>'cate190.png',
'shoptpltypename'=>'190_index_xj643',
'shoptpldesinfo'=>'不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>90,
),
array(
'shoptpltypeid'=>91,
'shoptplview'=>'cate191.png',
'shoptpltypename'=>'191_index_zedv',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>91,
),
array(
'shoptpltypeid'=>92,
'shoptplview'=>'cate192.png',
'shoptpltypename'=>'192_index_vbrn',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>92,
),
array(
'shoptpltypeid'=>93,
'shoptplview'=>'cate193.png',
'shoptpltypename'=>'193_index_b4bt',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>93,
),
array(
'shoptpltypeid'=>94,
'shoptplview'=>'cate194.png',
'shoptpltypename'=>'194_index_sc23',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>94,
),
array(
'shoptpltypeid'=>95,
'shoptplview'=>'cate195.png',
'shoptpltypename'=>'195_index_xrb54',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>95,
),
array(
'shoptpltypeid'=>96,
'shoptplview'=>'cate196.png',
'shoptpltypename'=>'196_index_sdf3',
'shoptpldesinfo'=>'图片要么都是正方形300x300px，要么都是360x200px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>96,
),
array(
'shoptpltypeid'=>97,
'shoptplview'=>'cate197.png',
'shoptpltypename'=>'197_index_cvrj',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>97,
),
array(
'shoptpltypeid'=>98,
'shoptplview'=>'cate198.png',
'shoptpltypename'=>'198_index_xcwh',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>98,
),
array(
'shoptpltypeid'=>99,
'shoptplview'=>'cate199.png',
'shoptpltypename'=>'199_index_asdw',
'shoptpldesinfo'=>'图标为正方形300x300px，图片高度90，宽度不小于360px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>99,
),
array(
'shoptpltypeid'=>100,
'shoptplview'=>'cate1100.png',
'shoptpltypename'=>'1100_index_btj5',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu bg filt slip',
'sort'=>100,
),
array(
'shoptpltypeid'=>101,
'shoptplview'=>'cate1101.png',
'shoptpltypename'=>'1101_index_sd3h',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu bg filt slip',
'sort'=>101,
),
array(
'shoptpltypeid'=>102,
'shoptplview'=>'cate1102.png',
'shoptpltypename'=>'1102_index_cvb5u',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu bg filt slip',
'sort'=>118,
),
array(
'shoptpltypeid'=>103,
'shoptplview'=>'cate1103.png',
'shoptpltypename'=>'1103_index_xfe5',
'shoptpldesinfo'=>'图标为正方形300x300px，图片建议360x200px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>119,
),
array(
'shoptpltypeid'=>104,
'shoptplview'=>'cate1104.png',
'shoptpltypename'=>'1104_index_xcvhk',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb filt bg',
'sort'=>120,
),
array(
'shoptpltypeid'=>105,
'shoptplview'=>'cate1105.png',
'shoptpltypename'=>'1105_index_fxfg',
'shoptpldesinfo'=>'图标为正方形300x300px，图片建议360x200px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>121,
),
array(
'shoptpltypeid'=>106,
'shoptplview'=>'cate1106.png',
'shoptpltypename'=>'1106_index_fxfg',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu',
'sort'=>122,
),
array(
'shoptpltypeid'=>107,
'shoptplview'=>'cate1107.png',
'shoptpltypename'=>'1107_index_fxfg',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu slip',
'sort'=>123,
),
array(
'shoptpltypeid'=>108,
'shoptplview'=>'cate1108.png',
'shoptpltypename'=>'1108_index_fxfg',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu slip',
'sort'=>124,
),
array(
'shoptpltypeid'=>109,
'shoptplview'=>'cate1109.png',
'shoptpltypename'=>'1109_index_fxfg',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu slip',
'sort'=>125,
),
array(
'shoptpltypeid'=>110,
'shoptplview'=>'cate1110.png',
'shoptpltypename'=>'1110_index_fxfg',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu slip',
'sort'=>126,
),
array(
'shoptpltypeid'=>111,
'shoptplview'=>'cate1111.png',
'shoptpltypename'=>'1111_index_cveg',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu slip',
'sort'=>127,
),
array(
'shoptpltypeid'=>112,
'shoptplview'=>'cate1112.png',
'shoptpltypename'=>'1112_index_xghx',
'shoptpldesinfo'=>'小图标为正方形300x300px。不支持更换颜色风格',
'attr'=>'bgs thumb focu slip',
'sort'=>128,
),
array(
'shoptpltypeid'=>113,
'shoptplview'=>'cate1113.png',
'shoptpltypename'=>'1113_index_cxve',
'shoptpldesinfo'=>'支持二级分类，并且一级分类和子分类支持左右滑屏显示。前8个一级分类可以突出显示，小图标为正方形300x300px，图片要么都是正方形300x300px，要么都是360x200px。不支持更换颜色风格',
'attr'=>'bgs thumb focu sub slip',
'sort'=>129,
),
array(
'shoptpltypeid'=>114,
'shoptplview'=>'cate1114.png',
'shoptpltypename'=>'1114_index_vbtd',
'shoptpldesinfo'=>'支持二级分类，并且一级分类和子分类支持左右滑屏显示。适合分类比较多的地方公众号，前4个一级分类可以突出显示，小图标为正方形300x300px，图片要么都是正方形300x300px，要么都是360x200px。不支持更换颜色风格',
'attr'=>'bgs thumb focu sub slip',
'sort'=>130,
),
array(
'shoptpltypeid'=>115,
'shoptplview'=>'cate1115.png',
'shoptpltypename'=>'1115_index_v3yh',
'shoptpldesinfo'=>'支持二级分类，并且一级分类和子分类支持左右滑屏显示。适合分类比较多的地方公众号，前4个一级分类可以突出显示，小图标为正方形300x300px；图片要么都是正方形300x300px，要么都是360x200px。不支持更换颜色风格',
'attr'=>'bgs thumb focu sub slip',
'sort'=>131,
),
array(
'shoptpltypeid'=>116,
'shoptplview'=>'cate1116.png',
'shoptpltypename'=>'1116_index_cv4y',
'shoptpldesinfo'=>'支持二级分类，并且一级分类和子分类支持左右滑屏显示。适合分类比较多的地方公众号，前4个一级分类可以突出显示，图片要么都是正方形300x300px，要么都是360x200px。不支持更换颜色风格',
'attr'=>'bgs thumb focu sub slip',
'sort'=>132,
),
array(
'shoptpltypeid'=>117,
'shoptplview'=>'cate1117.png',
'shoptpltypename'=>'1117_index_35y5',
'shoptpldesinfo'=>'顶级最多显示6个分类，二级最多显示3个分类，不支持更换颜色风格',
'attr'=>'sub bg',
'sort'=>117,
),
array(
'shoptpltypeid'=>118,
'shoptplview'=>'cate1118.png',
'shoptpltypename'=>'1118_index_sdsc',
'shoptpldesinfo'=>'可自定义背景轮播图，不支持更换颜色风格',
'attr'=>'bg bgs filt lis',
'sort'=>116,
),
array(
'shoptpltypeid'=>119,
'shoptplview'=>'cate1119.png',
'shoptpltypename'=>'1119_index_asd52',
'shoptpldesinfo'=>'适合在列表页使用，不支持更换颜色风格',
'attr'=>'lis thumb',
'sort'=>115,
),
array(
'shoptpltypeid'=>120,
'shoptplview'=>'cate1120.png',
'shoptpltypename'=>'1120_index_ghg6',
'shoptpldesinfo'=>'适合在列表页使用，不支持更换颜色风格',
'attr'=>'lis thumb',
'sort'=>114,
),
array(
'shoptpltypeid'=>121,
'shoptplview'=>'cate1121.png',
'shoptpltypename'=>'1121_index_8sd55',
'shoptpldesinfo'=>'适合在列表页使用，不支持更换颜色风格',
'attr'=>'lis thumb',
'sort'=>113,
),
array(
'shoptpltypeid'=>122,
'shoptplview'=>'cate1122.png',
'shoptpltypename'=>'1122_index_5sd2',
'shoptpldesinfo'=>'适合在列表页使用，不支持更换颜色风格',
'attr'=>'lis thumb',
'sort'=>112,
),
array(
'shoptpltypeid'=>123,
'shoptplview'=>'cate1123.png',
'shoptpltypename'=>'1123_index_cvrn',
'shoptpldesinfo'=>'适合在列表页使用，不支持更换颜色风格',
'attr'=>'lis thumb',
'sort'=>111,
),
array(
'shoptpltypeid'=>124,
'shoptplview'=>'cate1124.png',
'shoptpltypename'=>'1124_index_xegb',
'shoptpldesinfo'=>'适合在列表页使用，不支持更换颜色风格',
'attr'=>'lis thumb',
'sort'=>110,
),
array(
'shoptpltypeid'=>125,
'shoptplview'=>'cate1125.png',
'shoptpltypename'=>'1125_index_xcvy',
'shoptpldesinfo'=>'适合在列表页使用，不支持更换颜色风格',
'attr'=>'lis thumb',
'sort'=>109,
),
array(
'shoptpltypeid'=>126,
'shoptplview'=>'cate1126.png',
'shoptpltypename'=>'1126_index_85vvb',
'shoptpldesinfo'=>'适合在列表页使用，不支持更换颜色风格',
'attr'=>'lis thumb',
'sort'=>108,
),
array(
'shoptpltypeid'=>127,
'shoptplview'=>'cate1127.png',
'shoptpltypename'=>'1127_index_klgh',
'shoptpldesinfo'=>'适合在列表页使用，不支持更换颜色风格',
'attr'=>'lis thumb',
'sort'=>107,
),
array(
'shoptpltypeid'=>128,
'shoptplview'=>'cate1128.png',
'shoptpltypename'=>'1128_index_vner',
'shoptpldesinfo'=>'适合在列表页使用，不支持更换颜色风格',
'attr'=>'lis thumb',
'sort'=>106,
),
array(
'shoptpltypeid'=>129,
'shoptplview'=>'cate1129.png',
'shoptpltypename'=>'1129_index_vner',
'shoptpldesinfo'=>'适合在列表页使用，不支持更换颜色风格',
'attr'=>'lis thumb',
'sort'=>105,
),
array(
'shoptpltypeid'=>130,
'shoptplview'=>'cate1130.png',
'shoptpltypename'=>'1130_index_85xc',
'shoptpldesinfo'=>'适合在列表页使用，不支持更换颜色风格',
'attr'=>'lis thumb',
'sort'=>104,
),
array(
'shoptpltypeid'=>131,
'shoptplview'=>'cate1131.png',
'shoptpltypename'=>'1131_index_nr34',
'shoptpldesinfo'=>'适合在列表页使用，不支持更换颜色风格',
'attr'=>'lis thumb',
'sort'=>103,
),
array(
'shoptpltypeid'=>132,
'shoptplview'=>'cate1132.png',
'shoptpltypename'=>'1132_index_mng5',
'shoptpldesinfo'=>'适合在列表页使用，不支持更换颜色风格',
'attr'=>'lis thumb',
'sort'=>102,
),
array(
'shoptpltypeid'=>133,
'shoptplview'=>'cate1133.png',
'shoptpltypename'=>'1133_index_rgcv',
'shoptpldesinfo'=>'不支持更换颜色风格',
'attr'=>'focu thumb bgs',
'sort'=>133,
),
array(
'shoptpltypeid'=>134,
'shoptplview'=>'cate1134.png',
'shoptpltypename'=>'1134_index_cv4s',
'shoptpldesinfo'=>'支持二级分类，并且一级分类和子分类支持左右滑屏显示。头部图片尺寸推荐360x45，中间的大图就是一级分类图片，尺寸推荐360x100，不支持更换颜色风格',
'attr'=>'focu thumb bgs sub',
'sort'=>134,
),
array(
'shoptpltypeid'=>135,
'shoptplview'=>'cate1135.png',
'shoptpltypename'=>'1135_index_xcev',
'shoptpldesinfo'=>'支持二级分类，并且一级分类和子分类支持左右滑屏显示。头部图片尺寸推荐360x45，中间的大图就是一级分类图片，尺寸推荐360x100，二级分类图片尺寸推荐360x200px，不支持更换颜色风格',
'attr'=>'focu thumb bgs sub',
'sort'=>135,
),
array(
'shoptpltypeid'=>136,
'shoptplview'=>'cate1136.png',
'shoptpltypename'=>'1136_index_n4fb',
'shoptpldesinfo'=>'windowsphone风格，无幻灯片。分类的图片为300x300正方形图片，记住一定要相同的尺寸，都是300x300。',
'attr'=>'thumb',
'sort'=>136,
),
);
return $IIIIIIl1lI11;
?>