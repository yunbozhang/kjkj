<?php
header("Location: index.php?g=admin&m=Index&a=login");
?>